<footer class="footer">
      <div class="container">
        <span class="text-muted">Udemy Codeigniter Tutorials | Frank John</span>
      </div>
    </footer>
