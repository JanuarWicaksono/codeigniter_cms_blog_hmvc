<h2>Latest Posts</h2>
<?php
echo Modules::run('posts/blog/dashboard_posts');
 ?>
